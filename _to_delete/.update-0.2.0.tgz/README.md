# IntelliJ Light IDE

A high-density, PhpStorm New UI–inspired **light** theme for VS Code. Ships three parts:

| Part | Picker | What it covers |
| --- | --- | --- |
| Colour theme | *Preferences: Color Theme* → **IntelliJ Light IDE** | Editor, tabs, breadcrumbs, project tree, tool strip, run/terminal panel, status bar, JetBrains syntax colours (PHP-tuned) |
| File icons | *Preferences: File Icon Theme* → **IntelliJ Light File Icons** | 68 New UI–style icons: language badges (PHP, JSON, TS…), folders, `.env`/lock files, `artisan`, Docker, tests, images… |
| Product icons | *Preferences: Product Icon Theme* → **IntelliJ Light Product Icons** | Tool-window strip (project, commit, search, debug, plugins), chevrons, run ▶ / stop ■, breakpoints, bell, gear, branch, window controls |

## Recommended settings

```json
{
  "workbench.colorTheme": "IntelliJ Light IDE",
  "workbench.iconTheme": "intellij-light-file-icons",
  "workbench.productIconTheme": "intellij-light-product-icons",

  "editor.fontFamily": "'JetBrains Mono', monospace",
  "editor.fontSize": 13,
  "editor.lineHeight": 22,
  "editor.fontLigatures": true,
  "editor.semanticHighlighting.enabled": true,
  "editor.glyphMargin": true,
  "editor.renderLineHighlight": "all",
  "editor.minimap.renderCharacters": false,

  "workbench.tree.indent": 14,
  "workbench.tree.renderIndentGuides": "none",
  "workbench.editor.tabActionLocation": "right",
  "workbench.editor.highlightModifiedTabs": true,
  "breadcrumbs.enabled": true,
  "window.commandCenter": true,
  "window.titleBarStyle": "custom"
}
```

## Layout

```
themes/intellij-light-ide-color-theme.json   colour theme (JSONC, sectioned to match the IDE layout)
icons/intellij-light-file-icons.json         file icon theme
icons/files/*.svg                            file & folder icons (16×16)
icons/intellij-product-icons.json            product icon theme
icons/intellij-product-icons.woff            product icon font
scripts/build_*.py                           regenerate icons: `python3 scripts/build_file_icons.py .` / `python3 scripts/build_product_icons.py .` (needs fontTools)
```

The colour theme is split into numbered sections that follow the PhpStorm window top to bottom:
base → title bar / Search Everywhere → tool strip → project tree → tabs → breadcrumbs → editor & gutter →
popups → bottom tool window → status bar → controls → menus → VCS → run/debug/tests → misc,
then semantic tokens and TextMate scopes.

## Install locally

Copy this folder to `~/.vscode/extensions/intellij-light-ide`, restart VS Code and pick the three themes above.
Or press F5 in this folder to launch an Extension Development Host.

## Package

```bash
npm i -g @vscode/vsce
vsce package
```
